async function createWallet(){
  const label = document.getElementById("label").value;
  const initial = document.getElementById("initial").value;
  const res = await fetch('/api/wallet', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({label, initial_deposit: initial || "0"})
  });
  const j = await res.json();
  document.getElementById("create_result").textContent = JSON.stringify(j, null, 2);
}

async function getWallet(){
  const id = document.getElementById("wallet_id").value;
  if(!id) return alert("enter wallet id");
  const r = await fetch('/api/wallet/' + id);
  const j = await r.json();
  document.getElementById("wallet_area").textContent = JSON.stringify(j, null, 2);
}

async function deposit(){
  const id = document.getElementById("wallet_id").value;
  const amt = prompt("amount to deposit (e.g. 5.00):");
  if(!id || !amt) return;
  const r = await fetch('/api/wallet/' + id + '/deposit', {
    method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({amount:amt})
  });
  document.getElementById("wallet_area").textContent = JSON.stringify(await r.json(), null, 2);
}

async function withdraw(){
  const id = document.getElementById("wallet_id").value;
  const secret = document.getElementById("wallet_secret").value;
  const amt = prompt("amount to withdraw (e.g. 2.00):");
  if(!id || !amt || !secret) return alert("provide id, secret, amount");
  const r = await fetch('/api/wallet/' + id + '/withdraw', {
    method:'POST', headers:{'Content-Type':'application/json', 'X-WALLET-SECRET': secret}, body: JSON.stringify({amount:amt})
  });
  document.getElementById("wallet_area").textContent = JSON.stringify(await r.json(), null, 2);
}

async function listTxs(){
  const id = document.getElementById("wallet_id").value;
  if(!id) return;
  const r = await fetch('/api/txs/' + id);
  document.getElementById("wallet_area").textContent = JSON.stringify(await r.json(), null, 2);
}

async function transfer(){
  const from_id = document.getElementById("from_id").value;
  const from_secret = document.getElementById("from_secret").value;
  const to_id = document.getElementById("to_id").value;
  const amount = document.getElementById("transfer_amt").value;
  if(!from_id||!from_secret||!to_id||!amount) return alert("fill all fields");
  const r = await fetch('/api/transfer', {
    method:'POST',
    headers:{'Content-Type':'application/json', 'X-WALLET-SECRET': from_secret},
    body: JSON.stringify({from_id, to_id, amount})
  });
  document.getElementById("transfer_result").textContent = JSON.stringify(await r.json(), null, 2);
}

async function adminLogin(){
  const user = document.getElementById("admin_user").value;
  const pass = document.getElementById("admin_pass").value;
  const r = await fetch('/admin/login', {
    method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username:user, password:pass})
  });
  const j = await r.json();
  document.getElementById("admin_token").textContent = JSON.stringify(j, null, 2);
  if(j.access_token) localStorage.setItem('admin_token', j.access_token);
}

async function adminEdit(){
  const token = localStorage.getItem('admin_token');
  if(!token) return alert("login as admin first");
  const wid = document.getElementById("admin_wallet").value;
  const nb = document.getElementById("admin_new_balance").value;
  const r = await fetch('/api/admin/edit_balance', {
    method:'POST',
    headers:{'Content-Type':'application/json', 'Authorization': 'Bearer ' + token},
    body: JSON.stringify({wallet_id: wid, new_balance: nb})
  });
  document.getElementById("admin_edit_result").textContent = JSON.stringify(await r.json(), null, 2);
}
